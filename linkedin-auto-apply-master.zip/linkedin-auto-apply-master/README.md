# Linkedin Auto Apply
Linkedin Auto Apply with node.js and selenium;
You need to have [Chrome](https://www.google.com/intl/en-EN/chrome/) installed  
First thing, you need to run

````
yarn 
````

or

````
npm install 
````

in `index.js` change the variables:

`username`: your username in linkedin

`password`: your password in linkedin

`searchTerm`: term to search, ex: "java" or "front end'

`searchArea`: area to search, ex: "Lisbon" or "New York"


Obs: Use the language of your linkedin

## How to use

After config, just run `yarn start` or `npm start` and be happy with your new job :)